Accounting for Dairy Factory - Static Offline Web App (Arabic/English)
-----------------------------------------------------------------------
Files:
- index.html  : main app (HTML + links to styles and scripts)
- styles.css  : small CSS tweaks
- app.js      : main JavaScript app (localStorage persistence, bilingual, exports)
- README.txt  : this file

How to use:
1. Download the files and host them on any static hosting (Vercel, Netlify, GitHub Pages), or open index.html locally in a browser.
2. The app saves data in your browser's LocalStorage. Data persists on the same device/browser.
3. Settings: you can set factory name (optional), currency (default '₪'), language.
4. Features:
   - Add customers
   - Create invoices and expenses (multiple items)
   - Print invoices, Export CSV, Export PDF
   - Summary panel with totals and balance
   - Bilingual UI (switch top-right)

Deploy online (quick):
- Vercel: create a new project, import a Git repo with these files, or drag & drop the folder to Vercel dashboard -> it will deploy immediately.
- Netlify: drag & drop folder to Netlify Sites -> New site from folder.
- GitHub Pages: push to a repo and enable Pages.

If you want, I can:
- Prepare the GitHub repo structure with a ready `vercel.json` and instructions.
- Deploy it for you and give a live URL (I can provide step-by-step commands you can run).
