
// Simple offline accounting SPA - saves to localStorage
(function(){
  const LS_KEY = 'adf_data_v1';
  const DEFAULT = { settings:{factory:'', currency:'₪', lang:'ar'}, customers:[], entries:[] };
  let state = loadState();

  // DOM
  const langSel = document.getElementById('lang');
  const appTitle = document.getElementById('app-title');
  const factoryNameInput = document.getElementById('factoryName');
  const currencyInput = document.getElementById('currency');
  const saveSettingsBtn = document.getElementById('saveSettings');
  const btnNewInvoice = document.getElementById('btnNewInvoice');
  const btnNewExpense = document.getElementById('btnNewExpense');
  const sectionList = document.getElementById('sectionList');
  const totalSalesP = document.getElementById('totalSales');
  const totalExpensesP = document.getElementById('totalExpenses');
  const balanceP = document.getElementById('balance');
  const customersList = document.getElementById('customersList');
  const addCustomerBtn = document.getElementById('addCustomer');
  const customerNameInput = document.getElementById('customerName');
  const selectCustomer = document.getElementById('selectCustomer');

  // form panel
  const formPanel = document.getElementById('formPanel');
  const formTitle = document.getElementById('formTitle');
  const inputDate = document.getElementById('inputDate');
  const selectType = document.getElementById('selectType');
  const itemsTableBody = document.querySelector('#itemsTable tbody');
  const addItemRowBtn = document.getElementById('addItemRow');
  const saveFormBtn = document.getElementById('saveForm');
  const closeFormBtn = document.getElementById('closeForm');

  // export buttons
  const exportCSVBtn = document.getElementById('exportCSV');
  const exportPDFBtn = document.getElementById('exportPDF');

  // init UI values
  document.getElementById('factoryName').value = state.settings.factory || '';
  document.getElementById('currency').value = state.settings.currency || '₪';
  langSel.value = state.settings.lang || 'ar';

  // language strings
  const STR = {
    ar: {
      newInvoice: 'فاتورة جديدة',
      newExpense: 'مصروف جديد',
      sales: 'المبيعات',
      expenses: 'المصاريف',
      balance: 'الرصيد',
      invoice: 'فاتورة',
      expense: 'مصروف',
      save: 'حفظ',
      settingsSaved: 'تم حفظ الإعدادات'
    },
    en: {
      newInvoice: 'New Invoice',
      newExpense: 'New Expense',
      sales: 'Sales',
      expenses: 'Expenses',
      balance: 'Balance',
      invoice: 'Invoice',
      expense: 'Expense',
      save: 'Save',
      settingsSaved: 'Settings saved'
    }
  };

  function t(k){ return STR[state.settings.lang][k] || k; }

  // events
  langSel.addEventListener('change', ()=>{ state.settings.lang = langSel.value; saveState(); renderAll(); });
  saveSettingsBtn.addEventListener('click', ()=>{
    state.settings.factory = factoryNameInput.value.trim();
    state.settings.currency = currencyInput.value.trim() || '₪';
    saveState();
    alert(t('settingsSaved'));
    renderAll();
  });
  addCustomerBtn.addEventListener('click', ()=>{
    const name = customerNameInput.value.trim();
    if(!name) return;
    state.customers.push({id: Date.now(), name});
    saveState();
    customerNameInput.value='';
    renderAll();
  });
  btnNewInvoice.addEventListener('click', ()=> openForm('invoice'));
  btnNewExpense.addEventListener('click', ()=> openForm('expense'));
  addItemRowBtn.addEventListener('click', addItemRow);
  saveFormBtn.addEventListener('click', saveForm);
  closeFormBtn.addEventListener('click', ()=> formPanel.style.display='none');
  exportCSVBtn.addEventListener('click', exportCSV);
  exportPDFBtn.addEventListener('click', exportPDF);

  function loadState(){
    try {
      const raw = localStorage.getItem(LS_KEY);
      if(raw) return JSON.parse(raw);
    } catch(e){}
    return DEFAULT;
  }
  function saveState(){ localStorage.setItem(LS_KEY, JSON.stringify(state)); }

  function renderAll(){
    // title
    appTitle.textContent = state.settings.factory ? state.settings.factory + ' — Accounting' : 'Accounting for Dairy Factory';
    // lists
    renderCustomers();
    renderEntries();
    renderSummary();
    // language-specific labels
    document.getElementById('lbl-factory').textContent = state.settings.lang==='ar' ? 'اسم المصنع (اختياري)' : 'Factory name (optional)';
    document.getElementById('lbl-currency').textContent = state.settings.lang==='ar' ? 'العملة' : 'Currency';
    document.getElementById('lbl-summary').textContent = state.settings.lang==='ar' ? 'الملخص المالي' : 'Summary';
    document.getElementById('btnNewInvoice').textContent = t('newInvoice') + ' / ' + (state.settings.lang==='ar' ? 'فاتورة جديدة' : 'New Invoice');
    document.getElementById('btnNewExpense').textContent = t('newExpense') + ' / ' + (state.settings.lang==='ar' ? 'مصروف جديد' : 'New Expense');
  }

  function renderCustomers(){
    customersList.innerHTML = '';
    selectCustomer.innerHTML = '<option value="">' + (state.settings.lang==='ar' ? '-- عام / عام --' : '-- General --') + '</option>';
    state.customers.slice().reverse().forEach(c=>{
      const li = document.createElement('li'); li.className='list-group-item d-flex justify-content-between align-items-center';
      li.textContent = c.name;
      const btn = document.createElement('button'); btn.className='btn btn-sm btn-danger'; btn.textContent='حذف';
      btn.onclick = ()=> { state.customers = state.customers.filter(x=>x.id!==c.id); saveState(); renderAll(); };
      li.appendChild(btn);
      customersList.appendChild(li);

      const opt = document.createElement('option'); opt.value=c.id; opt.textContent=c.name;
      selectCustomer.appendChild(opt);
    });
  }

  function renderEntries(){
    sectionList.innerHTML = '';
    const tpl = document.getElementById('invoiceTemplate');
    const entries = state.entries.slice().reverse();
    entries.forEach(en=>{
      const node = tpl.content.cloneNode(true);
      node.querySelector('.inv-date').textContent = en.date;
      node.querySelector('.inv-customer').textContent = en.customerName || '';
      node.querySelector('.inv-total').textContent = (state.settings.currency || '₪') + ' ' + (en.total||0).toFixed(2);
      node.querySelector('.invoice-title').textContent = (en.type==='expense' ? (state.settings.lang==='ar' ? 'مصروف' : 'Expense') : (state.settings.lang==='ar' ? 'فاتورة' : 'Invoice'));
      const tbody = node.querySelector('.inv-items tbody');
      (en.items||[]).forEach(it=>{
        const tr = document.createElement('tr');
        tr.innerHTML = '<td>'+it.name+'</td><td>'+it.qty+'</td><td>'+ (state.settings.currency || '₪')+' '+Number(it.price).toFixed(2) +'</td><td>'+ (state.settings.currency || '₪')+' '+ (Number(it.qty)*Number(it.price)).toFixed(2) +'</td>';
        tbody.appendChild(tr);
      });
      node.querySelector('.btn-delete').addEventListener('click', ()=>{
        if(confirm('حذف؟ / Delete?')){ state.entries = state.entries.filter(x=>x.id!==en.id); saveState(); renderAll(); }
      });
      node.querySelector('.btn-print').addEventListener('click', ()=> printEntry(en));
      sectionList.appendChild(node);
    });
  }

  function renderSummary(){
    const sales = state.entries.filter(e=>e.type==='invoice').reduce((s,e)=>s+(e.total||0),0);
    const expenses = state.entries.filter(e=>e.type==='expense').reduce((s,e)=>s+(e.total||0),0);
    totalSalesP.textContent = (state.settings.lang==='ar' ? 'المبيعات: ' : 'Sales: ') + (state.settings.currency||'₪') + ' ' + sales.toFixed(2);
    totalExpensesP.textContent = (state.settings.lang==='ar' ? 'المصاريف: ' : 'Expenses: ') + (state.settings.currency||'₪') + ' ' + expenses.toFixed(2);
    balanceP.textContent = (state.settings.lang==='ar' ? 'الرصيد: ' : 'Balance: ') + (state.settings.currency||'₪') + ' ' + (sales - expenses).toFixed(2);
  }

  function openForm(type){
    formPanel.style.display='block';
    formTitle.textContent = (type==='invoice' ? (state.settings.lang==='ar' ? 'فاتورة جديدة' : 'New Invoice') : (state.settings.lang==='ar' ? 'تسجيل مصروف' : 'New Expense'));
    inputDate.value = new Date().toISOString().slice(0,10);
    selectType.value = (type==='invoice' ? 'invoice' : 'expense');
    itemsTableBody.innerHTML = '';
    addItemRow(); // start with one row
  }

  function addItemRow(){
    const tr = document.createElement('tr');
    tr.innerHTML = '<td><input class="form-control item-name" placeholder="وصف / item"></td><td><input class="form-control item-qty" type="number" value="1"></td><td><input class="form-control item-price" type="number" value="0"></td><td><button class="btn btn-sm btn-danger btn-rem">حذف</button></td>';
    tr.querySelector('.btn-rem').addEventListener('click', ()=> tr.remove());
    itemsTableBody.appendChild(tr);
  }

  function saveForm(){
    const type = selectType.value;
    const date = inputDate.value || new Date().toISOString().slice(0,10);
    const customerId = selectCustomer.value || '';
    const customerName = state.customers.find(c=>String(c.id)===String(customerId))?.name || '';
    const items = [];
    itemsTableBody.querySelectorAll('tr').forEach(r=>{
      const name = r.querySelector('.item-name').value || '';
      const qty = parseFloat(r.querySelector('.item-qty').value || 0) || 0;
      const price = parseFloat(r.querySelector('.item-price').value || 0) || 0;
      if(name && qty>0) items.push({name, qty, price});
    });
    if(items.length===0){ alert('أدخل عنصر واحد على الأقل\nEnter at least one item'); return; }
    const total = items.reduce((s,it)=>s + (it.qty*it.price), 0);
    const entry = { id: Date.now(), type: (type==='expense' ? 'expense' : 'invoice'), date, customerId, customerName, items, total };
    state.entries.push(entry);
    saveState();
    formPanel.style.display='none';
    renderAll();
  }

  function printEntry(e){
    const w = window.open('', '_blank');
    const title = state.settings.factory ? state.settings.factory : (state.settings.lang==='ar' ? 'فاتورة' : 'Invoice');
    let html = '<html><head><meta charset="utf-8"><title>'+title+'</title><style>body{font-family:Arial,Helvetica,sans-serif;direction:rtl}</style></head><body>';
    html += '<h2>'+ (state.settings.factory || title) + '</h2>';
    html += '<p>التاريخ: '+e.date+'</p>';
    html += '<p>العميل: '+(e.customerName||'—')+'</p>';
    html += '<table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>الصنف</th><th>كمية</th><th>سعر</th><th>المجموع</th></tr>';
    e.items.forEach(it=> html += '<tr><td>'+it.name+'</td><td>'+it.qty+'</td><td>'+ (state.settings.currency||'₪')+' '+Number(it.price).toFixed(2) +'</td><td>'+ (state.settings.currency||'₪')+' '+ (Number(it.qty)*Number(it.price)).toFixed(2) +'</td></tr>');
    html += '</table>';
    html += '<h3>المجموع: '+ (state.settings.currency||'₪') + ' ' + e.total.toFixed(2) + '</h3>';
    html += '</body></html>';
    w.document.write(html);
    w.document.close();
    w.print();
  }

  function exportCSV(){
    let rows = [];
    rows.push(['type','id','date','customer','item','qty','price','line_total']);
    state.entries.forEach(e=>{
      e.items.forEach(it=>{
        rows.push([e.type, e.id, e.date, e.customerName || '', it.name, it.qty, it.price, (it.qty*it.price)]);
      });
    });
    const csv = rows.map(r=> r.map(c=> '"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = (state.settings.factory ? state.settings.factory.replace(/\s+/g,'_') : 'accounting') + '_export.csv';
    document.body.appendChild(a); a.click(); a.remove();
  }

  async function exportPDF(){
    // simple PDF listing using jsPDF
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({unit:'pt'});
    doc.setFontSize(14);
    doc.text(state.settings.factory || 'Accounting for Dairy Factory', 40, 50);
    let y = 80;
    state.entries.forEach(e=>{
      doc.setFontSize(12);
      doc.text((e.type==='expense' ? (state.settings.lang==='ar' ? 'مصروف' : 'Expense') : (state.settings.lang==='ar' ? 'فاتورة' : 'Invoice')) + ' - ' + e.date, 40, y);
      y += 18;
      e.items.forEach(it=>{
        const line = `${it.name} | ${it.qty} x ${it.price} = ${(it.qty*it.price).toFixed(2)}`;
        doc.text(line, 60, y);
        y += 14;
        if(y > 750){ doc.addPage(); y = 40; }
      });
      doc.text('المجموع: ' + (state.settings.currency||'₪') + ' ' + e.total.toFixed(2), 60, y);
      y += 22;
      if(y > 750){ doc.addPage(); y = 40; }
    });
    doc.save((state.settings.factory ? state.settings.factory.replace(/\s+/g,'_') : 'accounting') + '.pdf');
  }

  // initial render
  renderAll();

  // expose simple helper for debugging
  window._adf_state = state;

})();
